---
type: doc
name: project-overview
description: High-level overview of the project, its purpose, and key components
category: overview
generated: 2026-03-04
status: unfilled
scaffoldVersion: "2.0.0"
---
## Project Overview

This is a **typescript** project. The codebase contains **17 files** with **10 symbols**.

## Codebase Reference

> **Detailed Analysis**: For complete symbol counts, architecture layers, and dependency graphs, see [`codebase-map.json`](./codebase-map.json).

## Quick Facts

- **Root**: `C:\Users\Ruan Miranda\WORKSPACE\GRACI\GRACI-LP-2026`
- **Languages**: javascript, typescript
- **Total Files**: 17
- **Total Symbols**: 10
- **Entry Point**: `index.tsx`
- **Full analysis**: [`codebase-map.json`](./codebase-map.json)

## Entry Points

- [`index.tsx`](../index.tsx)

## Key Exports

- `AIAnalysisResponse` (interface) - types.ts:28
- `Course` (interface) - types.ts:18
- `Feature` (interface) - types.ts:11
- `Testimonial` (interface) - types.ts:3

> See [`codebase-map.json`](./codebase-map.json) for complete list.

## File Structure & Code Organization

- `App.tsx/` — _describe purpose_
- `components/` — _describe purpose_
- `contexts/` — _describe purpose_
- `index.html/` — _describe purpose_
- `index.tsx/` — _describe purpose_
- `metadata.json/` — _describe purpose_
- `package-lock.json/` — _describe purpose_
- `package.json/` — _describe purpose_
- `README.md/` — _describe purpose_
- `services/` — _describe purpose_

## Technology Stack Summary

**Primary Language**: typescript

**Other Languages**: javascript

**Build Tools**: vite

**Package Manager**: npm

## Core Framework Stack

_No frameworks detected._

## UI & Interaction Libraries

<!-- List UI kits, CLI interaction helpers, or design system dependencies. Note theming, accessibility, or localization considerations. -->

_Content to be added._

## Development Tools Overview

<!-- Highlight essential CLIs, scripts, or developer environments. Link to Tooling guide for deeper setup. -->

_Content to be added._

## Getting Started Checklist

1. Install dependencies with `npm install`.
2. Start development with `npm run dev` or `npm start`.
3. Review the development workflow documentation.

## Next Steps

<!-- Capture product positioning, key stakeholders, and links to external documentation or product specs. -->

_Content to be added._

## Related Resources

- [architecture.md](./architecture.md)
- [development-workflow.md](./development-workflow.md)
- [tooling.md](./tooling.md)
- [codebase-map.json](./codebase-map.json)
